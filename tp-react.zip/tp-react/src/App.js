// src/App.js
import React from 'react';
import logo from './logorayo.png';
import './App.css';
import { Foot } from './components/Foot';
import { Hd } from './components/Hd';
import AdivinaContainer from './components/AdivinaContainer';
import Adivina from './components/Adivinanza'

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <Hd />
      </header>
      
      <main>
        <h1>Adivinanzas</h1>
        <Adivina />
        <AdivinaContainer />
      </main>

      <Foot />
    </div>
  );
}

export default App;
