import React from 'react'
import styles from "../styles/Footer.module.css"

export const Foot = () => {
  return (
    <div className={styles.footerContainer}>
      <p>© 2024 cuchau. Todos los derechos reservados.</p>
      <a href="https://www.youtube.com/watch?v=mdYKWh0SBGs&list=PLI1c12N4QIStQt_4d5yO1i1wxtIZO7FYG&index=4&ab_channel=CentroProvincialdelasArtesTeatroArgentino">redes</a>
    </div>
  )
}
