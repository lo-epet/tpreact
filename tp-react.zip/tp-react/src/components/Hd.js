import React from 'react';
import '../styles/header.module.css'; // Asegúrate de importar tu archivo CSS correctamente

export const Hd = () => {
  return (
    <div>
      <header>
        <h1>cuchau</h1>
        <nav>
          <ul>
            <li><a href="https://www.bing.com/images/search?view=detailV2&ccid=L0zTAklf&id=D1B640BE986C1FDAB003BF7F713A2EF1408EE7D1&thid=OIP.L0zTAklfigVtLRSgcDFQCgHaLT&mediaurl=https%3a%2f%2fimg.europapress.es%2ffotoweb%2ffotonoticia_20151211103625_800.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.2f4cd302495f8a056d2d14a07031500a%3frik%3d0eeOQPEuOnF%252fvw%26pid%3dImgRaw%26r%3d0&exph=1221&expw=800&q=carlos+gardel&simid=607998032368991691&FORM=IRPRST&ck=DFAFC44E3CFE8BBD471CA7591CAFCBA4&selectedIndex=0&itb=0&idpp=overlayview&ajaxhist=0&ajaxserp=0">Inicio</a></li>
            <li><a href="https://www.bing.com/images/search?view=detailV2&ccid=qu6dXwTO&id=6E016EC6202FB36F6149E6C30084BB6C0A64A639&thid=OIP.qu6dXwTOkKR4Hy65z43JDQHaEK&mediaurl=https%3a%2f%2fi.ytimg.com%2fvi%2fl2g4kPQAj3Q%2fmaxresdefault.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.aaee9d5f04ce90a4781f2eb9cf8dc90d%3frik%3dOaZkCmy7hADD5g%26pid%3dImgRaw%26r%3d0&exph=720&expw=1280&q=francesco+virgolini&simid=608009323858045113&FORM=IRPRST&ck=2854A519F2767C75C81037838193C193&selectedIndex=0&itb=0&idpp=overlayview&ajaxhist=0&ajaxserp=0">Sobre nosotros</a></li>
            <li><a href="https://www.bing.com/images/search?view=detailV2&ccid=H%2fzD%2blLw&id=0B59560B44B5CAF48D24F3FAD793459A4449C066&thid=OIP.H_zD-lLwoP1QYnUMYn1jnQHaHa&mediaurl=https%3a%2f%2fi.pinimg.com%2f736x%2f22%2f0d%2ff3%2f220df37b571dba90529518ebb37effdc.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.1ffcc3fa52f0a0fd5062750c627d639d%3frik%3dZsBJRJpFk9f68w%26pid%3dImgRaw%26r%3d0&exph=720&expw=720&q=Jesse+Pinkman+Foto+De+Perfil&simid=608020967513935968&FORM=IRPRST&ck=9CFDC93BFFBA49CFFAB994FC0DF8EC85&selectedIndex=0&itb=0&ajaxhist=0&ajaxserp=0">Contacto</a></li>
          </ul>

        </nav>
      </header>
    
    </div>
  );
};
